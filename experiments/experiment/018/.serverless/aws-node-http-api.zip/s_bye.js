
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'wonas',
  applicationName: 'testbed-aws-node-http-api',
  appUid: 'YCNQRQM9NnbLDjd0DX',
  orgUid: '9d9118de-e8aa-4ae5-9881-5077d190d24b',
  deploymentUid: '9ab21ce8-7d22-4069-a5e1-7e1366694c49',
  serviceName: 'aws-node-http-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.0.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'aws-node-http-api-dev-bye', timeout: 20 };

try {
  const userHandler = require('./byeHandler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.bye, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}