
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'wonas',
  applicationName: 'testbed-aws-node-http-api',
  appUid: 'YCNQRQM9NnbLDjd0DX',
  orgUid: '9d9118de-e8aa-4ae5-9881-5077d190d24b',
  deploymentUid: '93809f12-7466-47bb-81d8-d92fc4350c83',
  serviceName: 'aws-node-http-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.0.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'aws-node-http-api-dev-bye', timeout: 20 };

try {
  const userHandler = require('./byeHandler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.bye, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}